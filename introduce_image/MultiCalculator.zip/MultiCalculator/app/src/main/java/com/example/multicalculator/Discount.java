package com.example.multicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Discount extends AppCompatActivity {
    EditText orgPrice, discount;
    TextView txtSave, finPrice;
    Button btCalculate03;
    String strorg, strdisc;
    double org, fin,dis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discount);

        orgPrice = (EditText)findViewById(R.id.orgPrice);
        finPrice = (TextView)findViewById(R.id.finPrice);
        discount = (EditText)findViewById(R.id.discount);
        txtSave = (TextView)findViewById(R.id.txtSave);
        btCalculate03 = (Button)findViewById(R.id.btCalculate03);

        btCalculate03.setOnClickListener((v)->{

            strorg = orgPrice.getText().toString();
            strdisc = discount.getText().toString();
            org = Double.parseDouble(strorg);
            dis = Double.parseDouble(strdisc);

            fin = org*(1-(dis*0.01));
            double save = org - fin;

            txtSave.setText("You save:" + String.valueOf(save));
            finPrice.setText(String.valueOf(fin));

        });


    }
}
