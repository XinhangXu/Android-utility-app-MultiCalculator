package com.example.multicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;
import java.util.concurrent.atomic.AtomicInteger;

public class DateGap extends AppCompatActivity {

    TextView txtMon, txtYear, txtDay;
    EditText year1,year2,mon1,mon2,day1,day2;
    Button btCalculate;
    int year, mon, day,y1,y2,m1,m2,d1,d2;
    String yy1, yy2,mm1,mm2,dd1,dd2;
    Calendar cal01 = Calendar.getInstance();
    Calendar cal02 = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_gap);

         txtYear = (TextView)findViewById(R.id.year);
         txtMon = (TextView)findViewById(R.id.month);
         txtDay = (TextView)findViewById(R.id.day);
         year1 = (EditText)findViewById(R.id.y1);
         year2 = (EditText)findViewById(R.id.y2);
         mon1 = (EditText)findViewById(R.id.m1);
         mon2 = (EditText)findViewById(R.id.m2);
         day1 = (EditText)findViewById(R.id.d1);
         day2 = (EditText)findViewById(R.id.d2);
         btCalculate = (Button)findViewById(R.id.btCalculate);

        btCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yy1 = year1.getText().toString();
                yy2 = year2.getText().toString();
                mm1 = mon1.getText().toString();
                mm2 = mon2.getText().toString();
                dd1 = day1.getText().toString();
                dd2 = day2.getText().toString();
                y1 = Integer.parseInt(year1.getText().toString());
                y2 = Integer.parseInt(year2.getText().toString());
                m1 = Integer.parseInt(mon1.getText().toString());
                m2 = Integer.parseInt(mon2.getText().toString());
                d1 = Integer.parseInt(day1.getText().toString());
                d2 = Integer.parseInt(day2.getText().toString());

                cal01.set(y1, m1, d1);
                cal02.set(y2, m2, d2);
                long miliSecondForDate1 = cal01.getTimeInMillis();
                long miliSecondForDate2 = cal02.getTimeInMillis();
                long diffInMilis = miliSecondForDate2 - miliSecondForDate1;
                long diffInDays = diffInMilis / (24 * 60 * 60 * 1000);
                String r = String.valueOf(diffInDays);
                int days = Integer.parseInt(r);
                //txtDay.setText(r);
                year = (days - (days % 365))/365;
                mon = ((days - (365*year)) - ((days - (365*year)) % 31)) / 31;
                day = (days - (365*year) - (31*mon));
                if(m1>=1 && m1 <=12 && m2>=1 && m2 <=12 && d1>=1 && d1<=31 && d2>=1 && d2<=31){
                    txtDay.setText(String.valueOf(Math.abs(day)));
                    txtMon.setText(String.valueOf(Math.abs(mon)));
                    txtYear.setText(String.valueOf(Math.abs(year)));
                }else{
                    txtDay.setText("error");
                    txtMon.setText("error");
                    txtYear.setText("error");
                }









            /*if(!yy1.isEmpty() && !yy2.isEmpty() && !mm1.isEmpty() && !mm2.isEmpty() && !dd1.isEmpty() && !dd2.isEmpty()){

                if(y1 == y1){
                    year = 0;
                    if(m1 == m2){
                        mon = 0;
                        day = Math.abs(d1-d2);
                    }else{
                        if(d1 == d2){
                            day = 0;
                            mon = Math.abs(m1-m2);
                        }
                        if(d1 < d2){
                            day = Math.abs(d1-d2);
                            mon = Math.abs(m1-m2);
                        }
                        if(d1 > d2){
                            mon = Math.abs(m1-m2) - 1;
                            day = 31-d1+d2;
                        }
                    }
                }

                if(y1 < y2){
                    if(m1<m2){
                        if(d1 == d2){
                            year = Math.abs(y2-y1);
                            day = 0;
                            mon = Math.abs(m2-m1);
                        }
                        if(d1 < d2){
                            year = Math.abs(y2-y1);
                            day = Math.abs(d2-d1);
                            mon = Math.abs(m2-m1);
                        }
                        if(d1 > d2){
                            year = Math.abs(y2-y1);
                            mon = Math.abs(m1-m2) - 1;
                            day = 31-d1+d2;
                        }
                    }
                    if(m1==m2){
                        if(d1 < d2){
                            mon = 0;
                            year = Math.abs(y2-y1);
                            day = Math.abs(d2-d1);
                        }
                        if(d1 > d2){
                            mon = 12-1;
                            year = Math.abs(y1-y2)-1;
                            day = Math.abs(d1-d2);
                        }
                        if(d1 == d2){
                            year = Math.abs(y1-y2);
                            day = 0;
                            mon = 0;
                        }
                    }
                    if(m1 > m2){
                        if(d1 < d2){
                            year = Math.abs(y1-y2)-1;
                            mon = Math.abs(m1-m2);
                            day = Math.abs(d2-d1);
                        }
                        if(d1 > d2){
                            year = Math.abs(y1-y2)-1;
                            mon = 12-m1+m2 - 1;
                            day = 31-d1+d2;
                        }
                        if(d1 == d2){
                            year = Math.abs(y1-y2)-1;
                            mon = 12-m1+m2;
                            day = 0;
                        }

                    }
                }

                if(y1 > y2){
                    if(m1<m2){
                        if(d1 == d2){
                            year = Math.abs(y2-y1);
                            day = 0;
                            mon = Math.abs(m2-m1);
                        }
                        if(d1 < d2){
                            year = Math.abs(y2-y1);
                            day = Math.abs(d2-d1);
                            mon = Math.abs(m2-m1);
                        }
                        if(d1 > d2){
                            year = Math.abs(y2-y1);
                            mon = Math.abs(m1-m2) - 1;
                            day = 31-d1+d2;
                        }
                    }
                    if(m1==m2){
                        if(d1 < d2){
                            mon = 0;
                            year = Math.abs(y2-y1);
                            day = Math.abs(d2-d1);
                        }
                        if(d1 > d2){
                            mon = 12-1;
                            year = Math.abs(y1-y2)-1;
                            day = Math.abs(d1-d2);
                        }
                        if(d1 == d2){
                            year = Math.abs(y1-y2);
                            day = 0;
                            mon = 0;
                        }
                    }
                    if(m1 > m2){
                        if(d1 < d2){
                            year = Math.abs(y1-y2)-1;
                            mon = Math.abs(m1-m2);
                            day = Math.abs(d2-d1);
                        }
                        if(d1 > d2){
                            year = Math.abs(y1-y2);
                            mon = 12-m1+m2;
                            day = d1-d2;
                        }
                        if(d1 == d2){
                            year = Math.abs(y1-y2)-1;
                            mon = 12-m1+m2;
                            day = 0;
                        }

                    }
                }

                txtDay.setText(String.valueOf(day));
                txtMon.setText(String.valueOf(mon));
                txtYear.setText(String.valueOf(year));
            }else{
                txtYear.setText("error");
                txtMon.setText("error");
                txtDay.setText("error");
            }
*/
            }
        });






    }
}
