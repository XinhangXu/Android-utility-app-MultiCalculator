package com.example.multicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Notes extends AppCompatActivity {

    Button btSave01, btSave02, btSave03;
    EditText txtInput;
    TextView txt01, txt02, txt03;
    String note1, note2, note3;
    String n1, n2, n3;
    public static String SHARED_PREFS = "sharedPrefs";
    public static String TEXT1 = "test1";//shared to preference called test1
    public static String TEXT2 = "test2";
    public static String TEXT3 = "test3";
    //public static String BTSAVE01 = "btSave01";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        btSave03 = (Button)findViewById(R.id.btSave03);
        btSave02 = (Button)findViewById(R.id.btSave02);
        btSave01 = (Button)findViewById(R.id.btSave01);
        txtInput = (EditText)findViewById(R.id.txtInput);
        txt01 = (TextView)findViewById(R.id.txtNotes01);
        txt02 = (TextView)findViewById(R.id.txtNotes02);
        txt03 = (TextView)findViewById(R.id.txtNotes03);

        btSave01.setOnClickListener((v)->{
            saveData01();
            txt01.setText(n1);
        });
        btSave02.setOnClickListener((v)->{
            saveData02();
            txt02.setText(n2);
        });
        btSave03.setOnClickListener((v)->{
            saveData03();
            txt03.setText(n3);
        });

        loadData01();
        loadData02();
        loadData03();
    }

    public void saveData01(){
        n1 = txtInput.getText().toString();
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT1, txtInput.getText().toString());
        editor.apply();
        Toast.makeText(this, "Notes 1 saved", Toast.LENGTH_SHORT).show();
    }

    public void loadData01(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        note1 = sharedPreferences.getString(TEXT1, "");
        txt01.setText(note1);
    }

    public void saveData02(){
        n2 = txtInput.getText().toString();
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT2, txtInput.getText().toString());
        editor.apply();
        Toast.makeText(this, "Notes 2 saved", Toast.LENGTH_SHORT).show();
    }

    public void loadData02(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        note2 = sharedPreferences.getString(TEXT2, "");
        txt02.setText(note2);
    }

    public void saveData03(){
        n3 = txtInput.getText().toString();
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT2, txtInput.getText().toString());
        editor.apply();
        Toast.makeText(this, "Notes 3 saved", Toast.LENGTH_SHORT).show();
    }

    public void loadData03(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        note3 = sharedPreferences.getString(TEXT3, "");
        txt03.setText(note3);
    }


}
