package com.example.multicalculator;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {


    String Items[] = new String[]{"   (*^▽^*)        Normal Calculator       (*^▽^*)", "   (*≧▽≦)               Date Gap                  (*≧▽≦)",
            "   (*′☉.̫☉)            Calculate BMI            (*′☉.̫☉)", "   ୧( ॑ധ ॑)୨        Calculate Discount        ୧( ॑ധ ॑)୨",
            "   (๑>◡<๑)             Take Notes             (๑>◡<๑)"};

    Button btBlue, btGreen, btWhite;
    ConstraintLayout myLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btWhite = (Button) findViewById(R.id.btWhite);
        btBlue = (Button) findViewById(R.id.btBlue);
        btGreen = (Button) findViewById(R.id.btGreen);
        myLayout=(ConstraintLayout) findViewById(R.id.constraintlayout);

        ListView listView = (ListView) findViewById(R.id.mylist);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, Items);
        listView.setAdapter(adapter);

        btBlue.setOnClickListener((v)->{
            myLayout.setBackgroundColor(Color.BLUE);
        });
        btWhite.setOnClickListener((v)->{
            myLayout.setBackgroundColor(Color.WHITE);
        });
        btGreen.setOnClickListener((v)->{
            myLayout.setBackgroundColor(Color.GREEN);
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Toast.makeText(MainActivity.this, items[position], Toast.LENGTH_SHORT).show();
                if(position == 0){
                    Intent intent = new Intent(MainActivity.this, NormalCal.class);
                    startActivity(intent);
                }
                if(position == 1){
                    Intent intent = new Intent(MainActivity.this, DateGap.class);
                    startActivity(intent);
                }
                if(position == 2){
                    Intent intent = new Intent(MainActivity.this, BMI.class);
                    startActivity(intent);
                }
                if(position == 3){
                    Intent intent = new Intent(MainActivity.this, Discount.class);
                    startActivity(intent);
                }
                if(position == 4){
                    Intent intent = new Intent(MainActivity.this, Notes.class);
                    startActivity(intent);
                }
            }
        });

/*        btBlue.setOnClickListener((v)->{
            v.setBackgroundResource(R.color.blue);
        });
        btRed.setOnClickListener((v)->{
            v.setBackgroundResource(R.color.red);
        });
        btGreen.setOnClickListener((v)->{
            v.setBackgroundResource(R.color.green);
        });*/


    }
}
