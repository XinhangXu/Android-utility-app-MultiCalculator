package com.example.multicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BMI extends AppCompatActivity {
    EditText txtWt, txtHt;
    TextView myBMI;
    Button btCalculate02;
    String strwt, strht;
    double wt, ht;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);

        txtWt = (EditText)findViewById(R.id.myWt);
        txtHt = (EditText)findViewById(R.id.myHt);
        myBMI = (TextView) findViewById(R.id.myBMI);
        btCalculate02 = (Button)findViewById(R.id.btCalculate02);

        btCalculate02.setOnClickListener((v -> {
            strwt = txtWt.getText().toString();
            strht = txtHt.getText().toString();
            wt =  Double.parseDouble(strwt);
            ht =  Double.parseDouble(strht);

            if(!strwt.isEmpty() && !strht.isEmpty()){
                double a = Math.pow(ht*0.01,2);
                double result = wt/a;
                String x = String.format("%.1f", result);
                String r = String.valueOf(x);
                myBMI.setText("My BMI is " + r);
            }else{
                myBMI.setText("Error!!");
            }

        }));
    }
}
